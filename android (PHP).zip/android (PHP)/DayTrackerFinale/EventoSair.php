<?php 
    include "_conexao.php";

    // CHECK EXISTE
    $pedido = $PDO->prepare("SELECT * FROM participacao WHERE idEvento = :ID1 AND idUsuario = :ID2");
    $pedido->bindParam(':ID1', $_POST['idEvento']);
    $pedido->bindParam(':ID2', $_POST['idUsuario']);
    $pedido->execute();
    $existe = $pedido->fetch(PDO::FETCH_ASSOC);

    if ($existe) {
        $pedido = $PDO->prepare("DELETE FROM participacao WHERE idEvento = :ID1 AND idUsuario = :ID2");
        $pedido->bindParam(':ID1', $_POST['idEvento']);
        $pedido->bindParam(':ID2', $_POST['idUsuario']);
        $result = $pedido->execute();

        if ($result) {
            $dados = array("erro"=>"false","mensagem"=>"Participacao anulada");
            
        } else {
            $dados = array("erro"=>"true","mensagem"=>"Erro ao sair.");
        }
    } else {
        $dados = array("erro"=>"true","mensagem"=>"Participacao nao encontrado");
    }
    
            
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>

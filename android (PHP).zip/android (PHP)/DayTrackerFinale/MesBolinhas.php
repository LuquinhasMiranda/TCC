<?php 
    include "_conexao.php";
    
    $data1 = strtotime($_POST['dataComeco']);
    $data2 = strtotime($_POST['dataFim']);

    $compromissos = $PDO->prepare("SELECT data FROM cl18567.compromisso WHERE criador = :ID AND data >= :DATA1 AND data <= :DATA2");
    $compromissos->bindParam(':ID', $_POST['idCriador']);
    $compromissos->bindParam(':DATA1', $data1);
    $compromissos->bindParam(':DATA2', $data2);
    $compromissos->execute();

    $eventos = $PDO->prepare("SELECT data FROM evento WHERE criador = :ID AND data >= :DATA1 AND data <= :DATA2");
    $eventos->bindParam(':ID', $_POST['idCriador']);
    $eventos->bindParam(':DATA1', $data1);
    $eventos->bindParam(':DATA2', $data2);
    $eventos->execute();

    $part = $PDO->prepare("SELECT evento.data, evento.criador, participacao.idUsuario as participante 
    FROM evento, participacao 
    where evento.idEvento = participacao.idEvento 
    AND participacao.idUsuario = :ID AND data >= :DATA1 AND data <= :DATA2");
    $part->bindParam(':ID', $_POST['idCriador']);
    $part->bindParam(':DATA1', $data1);
    $part->bindParam(':DATA2', $data2);
    $part->execute();

    $anotacoes = $PDO->prepare("SELECT data FROM cl18567.anotacao WHERE criador = :ID AND data >= :DATA1 AND data <= :DATA2");
    $anotacoes->bindParam(':ID', $_POST['idCriador']);
    $anotacoes->bindParam(':DATA1', $data1);
    $anotacoes->bindParam(':DATA2', $data2);
    $anotacoes->execute();

    $bolinhas = array();
    $bolinhasAzul = array();
    while($linhaBD = $compromissos->fetch(PDO::FETCH_ASSOC)){
        $bolinhas[] = array("data" => date('Y/m/d', $linhaBD['data']));
    }
    while($linhaBD = $eventos->fetch(PDO::FETCH_ASSOC)){
        $bolinhas[] = array("data" => date('Y/m/d', $linhaBD['data']));
    }
    while($linhaBD = $part->fetch(PDO::FETCH_ASSOC)){
        $bolinhas[] = array("data" => date('Y/m/d', $linhaBD['data']));
    }
    while($linhaBD = $anotacoes->fetch(PDO::FETCH_ASSOC)){
        $bolinhasAzul[] = array("data" => date('Y/m/d', $linhaBD['data']));
    }

    $stringJson = array("Bolinhas" => $bolinhas, 
                        "BolinhasAzul" => $bolinhasAzul);
    echo json_encode($stringJson, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>
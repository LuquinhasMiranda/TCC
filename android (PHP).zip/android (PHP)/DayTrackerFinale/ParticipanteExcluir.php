<?php 
    include "_conexao.php";

    // CHECK EXISTE
    $pedido = $PDO->prepare("SELECT * FROM participacao WHERE idParticipacao = :ID");
    $pedido->bindParam(':ID', $_POST['idParticipacao']);
    $pedido->execute();
    $existe = $pedido->fetch(PDO::FETCH_ASSOC);

    if ($existe) {
        $pedido = $PDO->prepare("DELETE FROM participacao WHERE idParticipacao = :ID");
        $pedido->bindParam(':ID', $_POST['idParticipacao']);
        $result = $pedido->execute();

        if ($result) {
            $dados = array("erro"=>"false","mensagem"=>"Participante Excluido");
            
        } else {
            $dados = array("erro"=>"true","mensagem"=>"Erro ao excluir.");
        }
    } else {
        $dados = array("erro"=>"true","mensagem"=>"Participante nao encontrado");
    }
    
            
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>

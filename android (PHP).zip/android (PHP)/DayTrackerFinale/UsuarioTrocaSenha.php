<?php 
	include "_conexao.php";

	// UPDATE SENHA
	$stmt = $PDO->prepare("UPDATE usuario SET senha = :SENHA WHERE idUsuario = :ID");
	$stmt->bindParam(':SENHA', $_POST['senha']);
	$stmt->bindParam(':ID', $_POST['idUsuario']);	
	if($stmt->execute()){
		$dados = array("erro"=>"false",
						"mensagem"=>"Senha alterada.",
						"senha"=>$_POST['senha']);
	} else {
		$dados = array("erro"=>"true","mensagem"=>"Erro ao alterar");
	}
	echo json_encode($dados);

?>
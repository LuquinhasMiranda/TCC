<?php 
    include "_conexao.php";

    // CHECK EXISTE
    $pedido = $PDO->prepare("SELECT * FROM pedido_amizade WHERE idPedido = :ID");
    $pedido->bindParam(':ID', $_POST['idPedido']);
    $pedido->execute();
    $existe = $pedido->fetch(PDO::FETCH_ASSOC);

    if ($existe) {
        $stmt = $PDO->prepare("DELETE FROM pedido_amizade WHERE idPedido = :ID");
        $stmt->bindParam(':ID', $_POST['idPedido']);
        $result = $stmt->execute();

           if ($result != false) {
        $dados = array("erro"=>"false","mensagem"=>"Pedido de amizade excluido com sucesso.");
        } else {
        $dados = array("erro"=>"true","mensagem"=>"Erro ao excluir pedido.");
        }
    } else {
        $dados = array("erro"=>"true","mensagem"=>"Pedido nao encontrado");
    }
    
            
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>
<?php 
    include "_conexao.php";

    // CHECK EXISTE
    $pedido = $PDO->prepare("SELECT * FROM amizade WHERE idAmizade = :ID");
    $pedido->bindParam(':ID', $_POST['idAmizade']);
    $pedido->execute();
    $existe = $pedido->fetch(PDO::FETCH_ASSOC);
    //echo json_encode($ocupado);

    if ($existe) {
        $stmt = $PDO->prepare("DELETE FROM amizade WHERE idAmizade = :ID");
        $stmt->bindParam(':ID', $_POST['idAmizade']);
        $result = $stmt->execute();

           if ($result != false) {
        $dados = array("erro"=>"false","mensagem"=>"Amigo excluido com sucesso.");
        } else {
        $dados = array("erro"=>"true","mensagem"=>"Erro ao excluir amigo.");
        }
    } else {
        $dados = array("erro"=>"true","mensagem"=>"Amizade nao encontrada");
    }
    
            
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>
<?php 
	include "_conexao.php";

	// CHECK DISPONIBILIDADE
	$stmt = $PDO->prepare("SELECT * FROM usuario WHERE email = :EMAIL");
	$stmt->bindParam(':EMAIL', $_POST['email']);
	$stmt->execute();
	$ocupado = $stmt->fetch(PDO::FETCH_ASSOC);
	//echo json_encode($ocupado);

	if ($ocupado == false) {
		// REGISTRA USUARIO
		$stmt2 = $PDO->prepare("INSERT INTO usuario (nome, email, senha) VALUES (:NOME, :EMAIL, :SENHA)");
		$stmt2->bindParam(':NOME', $_POST['nome']);
		$stmt2->bindParam(':EMAIL', $_POST['email']);
		$stmt2->bindParam(':SENHA', $_POST['senha']);

		// Debugs
		if($stmt2->execute()){
		$dados = array("erro"=>"false","mensagem"=>"Registrado com sucesso");

		} else {	
		$dados = array("erro"=>"true", "mensagem"=>"Erro ao registrar");

		}
	} else {
		$dados = array("erro"=>"true", "mensagem"=>"Email ja cadastrado!");

	}
	echo json_encode($dados);
?>
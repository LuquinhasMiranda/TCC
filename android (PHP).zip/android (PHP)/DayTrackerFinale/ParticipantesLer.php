<?php 
	include "_conexao.php";

	// CHECK DISPONIBILIDADE
	$stmt = $PDO->prepare("SELECT * FROM participacao WHERE idEvento = :ID");
	$stmt->bindParam(':ID', $_POST['idEvento']);
	$stmt->execute();

    //como vou usar JSon, preciso jogar os dados num array
    $stringJson = array();
    $amigos = array();
   
    while($linhaBD = $stmt->fetch(PDO::FETCH_ASSOC)){
	    $stringJson[] = $linhaBD;

        //Procura pelo nome
        $stmt2 = $PDO->prepare("SELECT nome, idUsuario FROM usuario WHERE idUsuario = :ID");
        $stmt2->bindParam(':ID', $linhaBD['idUsuario']);
        $stmt2->execute();
        $amigos[] = $stmt2->fetch(PDO::FETCH_ASSOC);
    }

    //agora acontece a mágica -  transformar array em JSon
    $dados = array("participantes"=>$stringJson,
                   "nomes"=>$amigos);
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>

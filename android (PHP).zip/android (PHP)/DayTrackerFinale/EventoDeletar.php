<?php 
	include "_conexao.php";
	// UPDATE EMAIL  
	$stmt = $PDO->prepare("DELETE FROM evento WHERE idEvento = :ID");
	$stmt->bindParam(':ID', $_POST['idEvento']);
	if($stmt->execute()){
		$dados = array("erro"=>"false",
					   "mensagem"=>"Evento excluido com sucesso!");

		$stmt2 = $PDO->prepare("DELETE FROM participacao WHERE idEvento = :ID");
		$stmt2->bindParam(':ID', $_POST['idEvento']);
		$stmt2->execute();

		$stmt3 = $PDO->prepare("DELETE FROM convite_evento WHERE idEvento = :ID");
		$stmt3->bindParam(':ID', $_POST['idEvento']);
		$stmt3->execute();
		
	} else {
	$dados = array("erro"=>"true",
						"mensagem"=>"Erro!");
	}
echo json_encode($dados);
	
?>
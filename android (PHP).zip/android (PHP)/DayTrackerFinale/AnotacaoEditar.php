<?php 
	include "_conexao.php";
	$data = strtotime($_POST['data']);
	// UPDATE EMAIL  
	$stmt = $PDO->prepare("UPDATE anotacao SET conteudo = :CONTEUDO, titulo = :TITULO, data = :DATA WHERE idAnotacao = :ID");
	$stmt->bindParam(':TITULO', $_POST['titulo']);
	$stmt->bindParam(':DATA', $data);
	$stmt->bindParam(':CONTEUDO', $_POST['conteudo']);
	$stmt->bindParam(':ID', $_POST['idAnotacao']);
	if($stmt->execute()){
		$dados = array("erro"=>"false",
					   "mensagem"=>"Anotacao alterada com sucesso!");
	} else {
	$dados = array("erro"=>"true","mensagem"=>"Erro ao alterar");
	}

echo json_encode($dados);
	
?>
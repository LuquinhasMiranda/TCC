<?php 
	include "_conexao.php";
	$data = strtotime($_POST['data']);

	// Registra compromisso
	$stmt2 = $PDO->prepare("INSERT INTO evento (titulo, criador, data, hora, descricao) VALUES (:TITULO, :CRIADOR, :DATA, :HORA, :DESCRICAO)");
	$stmt2->bindParam(':TITULO', $_POST['titulo']);
	$stmt2->bindParam(':CRIADOR', $_POST['criador']);
	$stmt2->bindParam(':DATA', $data);
	$stmt2->bindParam(':HORA', $_POST['hora']);
	$stmt2->bindParam(':DESCRICAO', $_POST['descricao']);

	// Debugs
	if($stmt2->execute()){
	$dados = array("erro"=>"false","mensagem"=>"Evento criado com sucesso");

	} else {	
		$dados = array("erro"=>"true", "mensagem"=>"Erro ao criar evento");
	}

	echo json_encode($dados);
?>
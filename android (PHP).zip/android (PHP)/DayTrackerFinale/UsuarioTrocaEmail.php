<?php 
	include "_conexao.php";
	// CHECK DISPONIBILIDADE
	$stmt = $PDO->prepare("SELECT * FROM usuario WHERE email = :EMAIL");
	$stmt->bindParam(':EMAIL', $_POST['email']);
	$stmt->execute();
	$ocupado = $stmt->fetch(PDO::FETCH_ASSOC);
	//echo json_encode($ocupado);

	if ($ocupado == false) {
		// UPDATE EMAIL
		$stmt2 = $PDO->prepare("UPDATE usuario SET email = :EMAIL WHERE idUsuario = :ID");
		$stmt2->bindParam(':EMAIL', $_POST['email']);
		$stmt2->bindParam(':ID', $_POST['idUsuario']);	
		if($stmt2->execute()){
			$dados = array("erro"=>"false",
							"mensagem"=>"Email alterado.",
							"email"=>$_POST['email']);
		} else {
		$dados = array("erro"=>"true","mensagem"=>"Erro ao alterar");
		}
	} else {
		$dados = array("erro"=>"true","mensagem"=>"Este email ja esta registrado.");
	}

	echo json_encode($dados);
	
?>
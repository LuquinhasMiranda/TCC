<?php 
	include "_conexao.php";
	date_default_timezone_set('America/Sao_Paulo');
	$data = strtotime($_POST['data']);
	// CHECK DISPONIBILIDADE
	$stmt = $PDO->prepare("SELECT * FROM anotacao WHERE criador = :CRIADOR AND data = :DATA");
	$stmt->bindParam(':CRIADOR', $_POST['criador']);
	$stmt->bindParam(':DATA', $data);
	$stmt->execute();

    //como vou usar JSon, preciso jogar os dados num array
    $stringJson = array();
    while($linhaBD = $stmt->fetch(PDO::FETCH_ASSOC)){
	   $stringJson[] = array("idAnotacao" => $linhaBD['idAnotacao'],
							 "conteudo" => $linhaBD['conteudo'],
							 "titulo" => $linhaBD['titulo'],
							 "criador" => $linhaBD['criador'],
							 "data" => date('Y/m/d', $linhaBD['data']));
    }
 
    //agora acontece a mágica -  transformar array em JSon
    $dados = array("anotacoes"=>$stringJson);
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>

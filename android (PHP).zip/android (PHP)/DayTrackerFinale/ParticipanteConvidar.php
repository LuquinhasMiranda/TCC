<?php 
	include "_conexao.php";

	// CHECK AMIGO EXISTE
	$amigo = $PDO->prepare("SELECT idUsuario FROM usuario WHERE idUsuario = :ID");
	$amigo->bindParam(':ID', $_POST['idAmigo']);
	$amigo->execute();
	$existe = $amigo->fetch(PDO::FETCH_ASSOC);

	$amigo2 = $PDO->prepare("SELECT * FROM participacao WHERE idEvento = :ID1 AND idUsuario = :ID2");
	$amigo2->bindParam(':ID1', $_POST['idEvento']);
	$amigo2->bindParam(':ID2', $_POST['idAmigo']);
	$amigo2->execute();
	$existe2 = $amigo2->fetch(PDO::FETCH_ASSOC);

	$amigo3 = $PDO->prepare("SELECT * FROM convite_evento WHERE idEvento = :ID1 AND idUsuario = :ID2");
	$amigo3->bindParam(':ID1', $_POST['idEvento']);
	$amigo3->bindParam(':ID2', $_POST['idAmigo']);
	$amigo3->execute();
	$existe3 = $amigo3->fetch(PDO::FETCH_ASSOC);

	if ($existe) { 
		if ($existe2 == false && $existe3 == false) {
			// REGISTRA USUARIO
			$pedido = $PDO->prepare("INSERT INTO convite_evento (idEvento, idUsuario) VALUES (:ID, :USUARIO)");
			$pedido->bindParam(':ID', $_POST['idEvento']);
			$pedido->bindParam(':USUARIO', $existe['idUsuario']);

			// Debugs
			if($pedido->execute()){
				$dados = array("erro"=>"false","mensagem"=>"Convite enviado!");
			} else {
				$dados = array("erro"=>"true", "mensagem"=>"Erro ao enviar pedido.");
			}
		} else {
			$dados = array("erro"=>"true", "mensagem"=>"Convite ja enviado.");
		}
		
	} else {
		$dados = array("erro"=>"true", "mensagem"=>"Usuario nao encontrado.");

	}
	echo json_encode($dados);
?>
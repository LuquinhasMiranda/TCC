<?php 
	include "_conexao.php";
	// UPDATE EMAIL  
	$stmt = $PDO->prepare("DELETE FROM compromisso WHERE idCompromisso = :ID");
	$stmt->bindParam(':ID', $_POST['idCompromisso']);
	if($stmt->execute()){
		$dados = array("erro"=>"false",
						"mensagem"=>"Compromisso removido com sucesso!");
	} else {
	$dados = array("erro"=>"true",
						"mensagem"=>"Erro!");
	}
echo json_encode($dados);
	
?>
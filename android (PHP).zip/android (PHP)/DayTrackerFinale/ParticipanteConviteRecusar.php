<?php 
    include "_conexao.php";

    // CHECK EXISTE
    $pedido = $PDO->prepare("SELECT * FROM convite_evento WHERE idConvite = :ID");
    $pedido->bindParam(':ID', $_POST['idConvite']);
    $pedido->execute();
    $existe = $pedido->fetch(PDO::FETCH_ASSOC);

    if ($existe) {
        $pedido = $PDO->prepare("DELETE FROM convite_evento WHERE idConvite = :ID");
        $pedido->bindParam(':ID', $_POST['idConvite']);
        $result = $pedido->execute();

        if ($result) {
            $dados = array("erro"=>"false","mensagem"=>"Convite de participacao aceito!");
            
        } else {
            $dados = array("erro"=>"true","mensagem"=>"Erro ao confirmar.");
        }
    } else {
        $dados = array("erro"=>"true","mensagem"=>"Convite nao encontrado");
    }
    
            
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>

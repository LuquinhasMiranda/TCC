<?php 
	include "_conexao.php";
	$data = strtotime($_POST['data']);
	// UPDATE EMAIL  
	$stmt = $PDO->prepare("UPDATE evento SET descricao = :DESCRICAO, titulo = :TITULO, hora = :HORA, data = :DATA WHERE idEvento = :ID");
	$stmt->bindParam(':TITULO', $_POST['titulo']);
	$stmt->bindParam(':HORA', $_POST['hora']);
	$stmt->bindParam(':DATA', $data);
	$stmt->bindParam(':DESCRICAO', $_POST['descricao']);
	$stmt->bindParam(':ID', $_POST['idEvento']);
	if($stmt->execute()){
		$dados = array("erro"=>"false",
					   "mensagem"=>"Evento alterado com sucesso!");
	} else {
	$dados = array("erro"=>"true","mensagem"=>"Erro ao alterar");
	}

echo json_encode($dados);
	
?>
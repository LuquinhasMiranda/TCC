<?php  
		$dsn = "mysql:host=143.106.241.3:3306;dbname=cl18567;charset=utf8";
		$usuario = "cl18567";
		$senha = "cl*18122002";
		date_default_timezone_set('America/Sao_Paulo');

		try {
			$PDO = new PDO($dsn, $usuario, $senha);
			//echo "Conectado com sucesso!";

		} catch(PDOExeption $erro) {
			//echo "Erro na conexao com bd.";
		}

?>
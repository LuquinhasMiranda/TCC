<?php 
	include "_conexao.php";

	// CHECK AMIGO EXISTE
	$amigo = $PDO->prepare("SELECT idUsuario FROM usuario WHERE nome = :NOME AND idUsuario = :ID");
	$amigo->bindParam(':NOME', $_POST['nomeAmigo']);
	$amigo->bindParam(':ID', $_POST['idAmigo']);
	$amigo->execute();
	$existe = $amigo->fetch(PDO::FETCH_ASSOC);

	$amigo2 = $PDO->prepare("SELECT * FROM amizade WHERE (idUsuario1 = :ID1 OR idUsuario2 = :ID2) AND (idUsuario1 = :ID3 OR idUsuario2 = :ID4)");
	$amigo2->bindParam(':ID1', $_POST['idAmigo']);
	$amigo2->bindParam(':ID2', $_POST['idAmigo']);
	$amigo2->bindParam(':ID3', $_POST['idUsuario']);
	$amigo2->bindParam(':ID4', $_POST['idUsuario']);
	$amigo2->execute();
	$existe2 = $amigo2->fetch(PDO::FETCH_ASSOC);

	$amigo3 = $PDO->prepare("SELECT * FROM pedido_amizade WHERE (idUsuario1 = :ID1 OR idUsuario2 = :ID2) AND (idUsuario1 = :ID3 OR idUsuario2 = :ID4)");
	$amigo3->bindParam(':ID1', $_POST['idUsuario']);
	$amigo3->bindParam(':ID2', $_POST['idUsuario']);
	$amigo3->bindParam(':ID3', $existe['idUsuario']);
	$amigo3->bindParam(':ID4', $existe['idUsuario']);
	$amigo3->execute();
	$existe3 = $amigo3->fetch(PDO::FETCH_ASSOC);

	if ($existe) { 
		if ($existe2 == false && $existe3 == false) {
			// REGISTRA USUARIO
			$pedido = $PDO->prepare("INSERT INTO pedido_amizade (idUsuario1, idUsuario2) VALUES (:USUARIO1, :USUARIO2)");
			$pedido->bindParam(':USUARIO1', $_POST['idUsuario']);
			$pedido->bindParam(':USUARIO2', $existe['idUsuario']);

			// Debugs
			if($pedido->execute()){
				$dados = array("erro"=>"false","mensagem"=>"Pedido enviado!");
			} else {
				$dados = array("erro"=>"true", "mensagem"=>"Erro ao enviar pedido.");
			}
		} else {
			$dados = array("erro"=>"true", "mensagem"=>"Amigo ja adicionado.");
		}
		
	} else {
		$dados = array("erro"=>"true", "mensagem"=>"Usuario nao encontrado.");

	}
	echo json_encode($dados);
?>
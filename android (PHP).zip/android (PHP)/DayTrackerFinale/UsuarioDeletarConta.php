<?php 
	include "_conexao.php";
	// CHECK DISPONIBILIDADE
	$stmt = $PDO->prepare("SELECT * FROM usuario WHERE idUsuario = :ID");
	$stmt->bindParam(':ID', $_POST['idUsuario']);
	$stmt->execute();
	$ocupado = $stmt->fetch(PDO::FETCH_ASSOC);
	//echo json_encode($ocupado);

	if ($ocupado != false) {
		// UPDATE EMAIL
		$stmt2 = $PDO->prepare("DELETE FROM usuario WHERE idUsuario = :ID");
		$stmt2->bindParam(':ID', $_POST['idUsuario']);	
		if($stmt2->execute()){
			$stmt2 = $PDO->prepare("DELETE FROM compromisso WHERE criador = :ID");
			$stmt2->bindParam(':ID', $_POST['idUsuario']);
			$stmt2->execute();

			$stmt3 = $PDO->prepare("DELETE FROM evento WHERE criador = :ID");
			$stmt3->bindParam(':ID', $_POST['idUsuario']);
			$stmt3->execute();

			$stmt4 = $PDO->prepare("DELETE FROM participacao WHERE idUsuario = :ID");
			$stmt4->bindParam(':ID', $_POST['idUsuario']);
			$stmt4->execute();

			$stmt5 = $PDO->prepare("DELETE FROM convite_evento WHERE idUsuario = :ID");
			$stmt5->bindParam(':ID', $_POST['idUsuario']);
			$stmt5->execute();

			$stmt6 = $PDO->prepare("DELETE FROM amizade WHERE (idUsuario1 = :ID OR idUsuario2 = :ID)");
			$stmt6->bindParam(':ID', $_POST['idUsuario']);
			$stmt6->execute();

			$stmt7 = $PDO->prepare("DELETE FROM pedido_amizade WHERE (idUsuario1 = :ID OR idUsuario2 = :ID)");
			$stmt7->bindParam(':ID', $_POST['idUsuario']);
			$stmt7->execute();

		} else {
		$dados = array("erro"=>"true","mensagem"=>"Erro ao alterar");
		}
	} else {
		$dados = array("erro"=>"true","mensagem"=>"Esta conta ja foi deletada.");
	}

	echo json_encode($dados);
	
?>
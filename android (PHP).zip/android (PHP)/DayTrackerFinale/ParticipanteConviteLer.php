<?php 
	include "_conexao.php";

	// CHECK DISPONIBILIDADE
	$stmt = $PDO->prepare("SELECT * FROM convite_evento WHERE idUsuario = :ID");
	$stmt->bindParam(':ID', $_POST['idUsuario']);
	$stmt->execute();

    // cria arrays
    $stringJson = array();
    $eventos = array();
   
    while($linhaBD = $stmt->fetch(PDO::FETCH_ASSOC)){
	    $stringJson[] = $linhaBD;

        //Procura pelo titulo
        $stmt2 = $PDO->prepare("SELECT titulo, idEvento FROM evento WHERE idEvento = :ID");
        $stmt2->bindParam(':ID', $linhaBD['idEvento']);
        $stmt2->execute();
        $eventos[] = $stmt2->fetch(PDO::FETCH_ASSOC);
    }

    //agora acontece a mágica -  transformar array em JSon
    $dados = array("convites"=>$stringJson,
                   "eventos"=>$eventos);
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>
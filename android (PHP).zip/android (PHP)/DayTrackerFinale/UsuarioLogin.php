<?php 
	include "_conexao.php";

	// CHECK DISPONIBILIDADE
	$stmt = $PDO->prepare("SELECT * FROM usuario WHERE email = :EMAIL AND senha = :SENHA");
	$stmt->bindParam(':EMAIL', $_POST['email']);
	$stmt->bindParam(':SENHA', $_POST['senha']);
	$stmt->execute();
	$existe = $stmt->fetch(PDO::FETCH_ASSOC);
	
	if($existe != false){
		$dados = array("erro"=>"false",
						"mensagem"=>"Bem vindo",
						"idUsuario"=>$existe['idUsuario'],
						"nome"=>$existe['nome'],
						"email"=>$existe['email'],
						"senha"=>$existe['senha']);
	} else {
		$dados = array("erro"=>"true","mensagem"=>"Erro nas credenciais");
	}
	echo json_encode($dados);

?>
<?php 
	include "_conexao.php";

    // CHECK EXISTE
    $pedido = $PDO->prepare("SELECT * FROM convite_evento WHERE idConvite = :ID");
    $pedido->bindParam(':ID', $_POST['idConvite']);
    $pedido->execute();
    $existe = $pedido->fetch(PDO::FETCH_ASSOC);

    if ($existe) {
        $stmt = $PDO->prepare("INSERT INTO participacao (idEvento, idUsuario) VALUES (:EVENTO, :USUARIO)");
        $stmt->bindParam(':EVENTO', $existe['idEvento']);
        $stmt->bindParam(':USUARIO', $existe['idUsuario']);
        $result = $stmt->execute();

        if ($result) {
            $dados = array("erro"=>"false","mensagem"=>"Convite de participacao aceito!");
            $pedido = $PDO->prepare("DELETE FROM convite_evento WHERE idConvite = :ID");
            $pedido->bindParam(':ID', $_POST['idConvite']);
            $pedido->execute();
        } else {
            $dados = array("erro"=>"true","mensagem"=>"Erro ao confirmar.");
        }
    } else {
        $dados = array("erro"=>"true","mensagem"=>"Convite nao encontrado");
    }
	
            
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>

<?php 
	include "_conexao.php";
	$data = strtotime($_POST['data']);
	// Registra compromisso
	$stmt2 = $PDO->prepare("INSERT INTO anotacao (conteudo, criador, data, titulo) VALUES (:CONTEUDO, :CRIADOR, :DATA, :TITULO)");
	$stmt2->bindParam(':CONTEUDO', $_POST['conteudo']);
	$stmt2->bindParam(':CRIADOR', $_POST['criador']);
	$stmt2->bindParam(':TITULO', $_POST['titulo']);
	$stmt2->bindParam(':DATA', $data);
 
	// Debugs
	if($stmt2->execute()){
	$dados = array("erro"=>"false", "mensagem"=>"Anotação criada com sucesso");

	} else {
		$dados = array("erro"=>"true", "mensagem"=>"Erro ao criar anotação");
	}

	echo json_encode($dados);
?>
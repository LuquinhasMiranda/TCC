<?php 
	include "_conexao.php";

    // CHECK EXISTE
    $pedido = $PDO->prepare("SELECT * FROM pedido_amizade WHERE idPedido = :ID");
    $pedido->bindParam(':ID', $_POST['idPedido']);
    $pedido->execute();
    $existe = $pedido->fetch(PDO::FETCH_ASSOC);

    if ($existe) {
        $stmt = $PDO->prepare("INSERT INTO amizade (idUsuario1, idUsuario2) VALUES (:USUARIO1, :USUARIO2)");
        $stmt->bindParam(':USUARIO1', $existe['idUsuario1']);
        $stmt->bindParam(':USUARIO2', $existe['idUsuario2']);
        $result = $stmt->execute();

        if ($result) {
            $dados = array("erro"=>"false","mensagem"=>"Pedido de amizade aceito!");
            $pedido = $PDO->prepare("DELETE FROM pedido_amizade WHERE idPedido = :ID");
            $pedido->bindParam(':ID', $_POST['idPedido']);
            $pedido->execute();
        } else {
            $dados = array("erro"=>"true","mensagem"=>"Erro ao confirmar.");
        }
    } else {
        $dados = array("erro"=>"true","mensagem"=>"Pedido nao encontrado");
    }
	
            
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>

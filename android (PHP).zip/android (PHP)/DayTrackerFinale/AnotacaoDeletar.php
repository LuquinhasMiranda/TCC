<?php 
	include "_conexao.php";
	// UPDATE EMAIL  
	$stmt = $PDO->prepare("DELETE FROM anotacao WHERE idAnotacao = :ID");
	$stmt->bindParam(':ID', $_POST['idAnotacao']);
	if($stmt->execute()){
		$dados = array("erro"=>"false",
						"mensagem"=>"Anotação excluida com sucesso!");
	} else {
	$dados = array("erro"=>"true",
						"mensagem"=>"Erro!");
	}
echo json_encode($dados);
	
?>
<?php 
	include "_conexao.php";

	// CHECK DISPONIBILIDADE
	$stmt = $PDO->prepare("SELECT * FROM amizade WHERE idUsuario2 = :ID OR idUsuario1 = :ID2");
	$stmt->bindParam(':ID', $_POST['idUsuario']);
    $stmt->bindParam(':ID2', $_POST['idUsuario']);
	$stmt->execute();

    //como vou usar JSon, preciso jogar os dados num array
    $stringJson = array();
    $amigos = array();
   
    while($linhaBD = $stmt->fetch(PDO::FETCH_ASSOC)){
	    $stringJson[] = $linhaBD;

        //Diz qual nome achar
        if ($linhaBD['idUsuario1'] == $_POST['idUsuario']) {
            $idNome = $linhaBD['idUsuario2'];
        } else {
            $idNome = $linhaBD['idUsuario1'];
        }

        //Procura pelo nome
        $stmt2 = $PDO->prepare("SELECT nome, idUsuario FROM usuario WHERE idUsuario = :ID");
        $stmt2->bindParam(':ID', $idNome);
        $stmt2->execute();
        $amigos[] = $stmt2->fetch(PDO::FETCH_ASSOC);
    }

    //agora acontece a mágica -  transformar array em JSon
    $dados = array("amizades"=>$stringJson,
                   "amigos"=>$amigos);
    echo json_encode($dados, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>

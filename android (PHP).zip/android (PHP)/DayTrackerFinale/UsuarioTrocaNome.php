<?php 
	include "_conexao.php";

	// UPDATE NOME
	$stmt = $PDO->prepare("UPDATE usuario SET nome = :NOME WHERE idUsuario = :ID");
	$stmt->bindParam(':NOME', $_POST['nome']);
	$stmt->bindParam(':ID', $_POST['idUsuario']);	
	if($stmt->execute()){
		$dados = array("erro"=>"false",
						"mensagem"=>"Nome alterado.",
						"nome"=>$_POST['nome']);
	} else {
		$dados = array("erro"=>"true","mensagem"=>"Erro ao alterar");
	}
	echo json_encode($dados);

?>
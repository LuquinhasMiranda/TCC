<?php 
	include "_conexao.php";
	date_default_timezone_set('America/Sao_Paulo');
	$data = strtotime($_POST['data']);
	// Registra compromisso
	$stmt2 = $PDO->prepare("INSERT INTO compromisso (titulo, criador, data, hora, descricao, tipo) VALUES (:TITULO, :CRIADOR, :DATA, :HORA, :DESCRICAO, :TIPO)");
	$stmt2->bindParam(':TITULO', $_POST['titulo']);
	$stmt2->bindParam(':CRIADOR', $_POST['criador']);
	$stmt2->bindParam(':DATA', $data);
	$stmt2->bindParam(':HORA', $_POST['hora']);
	$stmt2->bindParam(':DESCRICAO', $_POST['descricao']);
	$stmt2->bindParam(':TIPO', $_POST['tipo']);

	// Debugs
	if($stmt2->execute()){
	$dados = array("erro"=>"false", "mensagem"=>"Agendado com sucesso");

	} else {
		$dados = array("erro"=>"true", "mensagem"=>"Erro ao agendar");
	}

	echo json_encode($dados);
?>